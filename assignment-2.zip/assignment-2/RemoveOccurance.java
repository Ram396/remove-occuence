package PracticeAssignment;

public class RemoveOccurance {
	public static void removeChar(String s, char ch) {
		int j, count = 0;
		int n = s.length();
		char[] temp = s.toCharArray();
		for (int i = j = 0; i < n; i++) {
			if (temp[i] != ch) {
				temp[j++] = temp[i];

			} else
				count++;
		}
		while(count>0) {
			temp[j++]='\0';
			count--;
		}
		System.out.println(temp);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "divijha";
		
		removeChar(s,'i');

	}

}
