package PracticeAssignment;

public class zeroToLast {

	public static void Zeros(int[] arr, int n) {
		int count = 0;
		for (int i = 0; i < n; i++) {
			if (arr[i] != 0) {
				arr[count++] = arr[i];

			}
		}
		while (count < n)
			arr[count++] = 0;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 1, 0, 2, 0, 3, 0, 4, 0, 5 };
		int n = arr.length;

		Zeros(arr, n);
		for (int i = 0; i < n; i++) {
			System.out.print(arr[i] + " ");

		}

	}

}
